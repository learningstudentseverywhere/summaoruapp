sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("namesp.summaoruappui.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);